from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
# from kbqa import KBQA_Evaluator
import pandas as pd
import requests
from bs4 import BeautifulSoup
import json
import lxml
from neo4j import GraphDatabase

# app = Flask(__name__)
app = Flask(__name__, static_folder='static', static_url_path='/static')

# enable CORS
CORS(app, supports_credentials=True, resources={r'/*': {'origins': '*'}})

@app.route('/')
def index():
    return render_template('test.html')

@app.route('/getAnswer', methods=['POST', 'GET'])
def Run():
    # 获取前端传递的请求参数
    userInput = request.get_json()['userInput']
    # print('testaaaaaaaaaa',userInput)
    result = query_api(userInput)  # 大模型查询结果
    # result = 'MATCH p=()-[r:`中药治疗`]->() RETURN p LIMIT 25'
    return result

def query_api(string):
    url = f"http://10.176.40.140:12121/?inpage=1&p={string}"
    response = requests.get(url)
    print(response,'----')
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        # print(soup)
        h4_tag = soup.find('h4', class_='ui horizontal header divider', string='Output')
        if h4_tag:
            h3_tag = h4_tag.find_next('h3')
            if h3_tag:
                extracted_data = h3_tag.text
                print(extracted_data)
                output = json.loads(extracted_data)
                return extracted_data
            else:
                print("没有找到相应的 <h3> 标签。")
                return '无法查询'
        else:
            return "没有找到相应的 <h4> 标签。"
    else:      
        return f"Error: {response.status_code}"

# CXT
@app.route('/getAnswerAuto', methods=['POST', 'GET'])
def query_auto():
    question = request.get_json()['question']
    url = f"http://10.222.148.31:4433/getAnswer?question={question}"
    response = requests.get(url)
    if response.status_code == 200:
        print("Response: ", response.text)
        return response.text
    else:
        return "<Error> Internal Server Error."
# CXT

if __name__ == '__main__':
    app.run(host="localhost", debug='True', port=5001)
